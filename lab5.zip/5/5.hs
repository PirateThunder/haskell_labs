data Vector2D x = Vector2D x x deriving (Show)
